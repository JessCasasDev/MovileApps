package co.edu.unal.companies;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import co.edu.unal.db.CompanyOperations;
import co.edu.unal.model.Company;

public class MainActivity extends AppCompatActivity {

    private Button addCompanyButton;
    private Button editCompanyButton;
    private Button deleteCompanyButton;
    private Button viewAllCompanyButton;
    private CompanyOperations companyOps;

    private static final String EXTRA_ADD_UPDATE = "co.edu.unal.add_update";
    private static final String EXTRA_COMP_ID = "co.edu.unal.id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        addCompanyButton = (Button) findViewById(R.id.button_add_company);
        editCompanyButton = (Button) findViewById(R.id.button_edit_company);
        deleteCompanyButton = (Button) findViewById(R.id.button_delete_company);
        viewAllCompanyButton = (Button)findViewById(R.id.button_view_company);



        addCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,AddUpdateCompany.class);
                i.putExtra(EXTRA_ADD_UPDATE, "Add");
                startActivity(i);
            }
        });
        editCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCompIdAndUpdateComp();
            }
        });
        deleteCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCompIdAndRemoveComp();
            }
        });
        viewAllCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ViewAllCompanies.class);
                startActivity(i);
            }
        });

    }

    public void getCompIdAndUpdateComp(){

        LayoutInflater li = LayoutInflater.from(this);
        View getCompIdView = li.inflate(R.layout.dialog_get_comp_id, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        // set dialog_get_emp_id.xml to alertdialog builder
        alertDialogBuilder.setView(getCompIdView);

        final EditText userInput = (EditText) getCompIdView.findViewById(R.id.editTextDialogUserInput);

        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("OK",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // get user input and set it to result
                        // edit text
                        Intent i = new Intent(MainActivity.this,AddUpdateCompany.class);
                        i.putExtra(EXTRA_ADD_UPDATE, "Update");
                        i.putExtra(EXTRA_COMP_ID, Long.parseLong(userInput.getText().toString()));
                        startActivity(i);
                    }
                }).create()
                .show();
    }

    public void getCompIdAndRemoveComp(){

        LayoutInflater li = LayoutInflater.from(this);
        View getEmpIdView = li.inflate(R.layout.dialog_get_comp_id, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        // set dialog_get_emp_id.xml to alertdialog builder
        alertDialogBuilder.setView(getEmpIdView);

        final EditText userInput = (EditText) getEmpIdView.findViewById(R.id.editTextDialogUserInput);

        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("OK",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // get user input and set it to result
                        // edit text
                        companyOps = new CompanyOperations(MainActivity.this);
                        companyOps.open();
                        Log.i("DElete", userInput.getText().toString());
                        final Company company = companyOps.getCompany(Long.parseLong(userInput.getText().toString()));
                        Log.i("DELETE COMPANY", company.toString());
                        if(company.getId() != 0){
                            LayoutInflater li = LayoutInflater.from(MainActivity.this);
                            View getCompIdView = li.inflate(R.layout.confirm_dialog, null);

                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                            // set dialog_get_emp_id.xml to alertdialog builder
                            alertDialogBuilder.setView(getCompIdView);

                            // set dialog message
                            alertDialogBuilder
                                    .setNegativeButton("NO",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            Toast t = Toast.makeText(MainActivity.this,"Ok, see you later!",Toast.LENGTH_SHORT);
                                            t.show();
                                        }
                                    })
                                    .setPositiveButton("YES",new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,int id) {
                                            // get user input and set it to result
                                            // edit text
                                            companyOps.removeCompany(company);
                                            Toast t = Toast.makeText(MainActivity.this,"Company removed successfully!",Toast.LENGTH_SHORT);
                                            t.show();
                                        }
                                    }).create()
                                    .show();
                        }
                        else{
                            Toast t = Toast.makeText(MainActivity.this,"Company does not exist",Toast.LENGTH_SHORT);
                            t.show();
                        }
                    }
                }).create()
                .show();
    }

}
