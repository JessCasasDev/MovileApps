package co.edu.unal.companies;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import co.edu.unal.db.CompanyOperations;
import co.edu.unal.model.Company;

public class AddUpdateCompany extends AppCompatActivity {

    private static final String EXTRA_COMP_ID = "co.edu.unal.id";
    private static final String EXTRA_ADD_UPDATE = "co.edu.unal.add_update";

    private static final String DIALOG_DATE = "DialogDate";
    private RadioGroup radioGroup;
    private RadioButton consultingRadioButton,developmentRadioButton, factoryRadioButton;
    private EditText nameEditText;
    private EditText urlEditText;
    private EditText phoneEditText;
    private EditText emailEditText;
    private EditText productsEditText;
    private Button addUpdateButton;
    private Company newCompany;
    private Company oldCompany;
    private String mode;
    private long compId;
    private CompanyOperations companyData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_update_company);
        newCompany = new Company();
        newCompany.setType("Consulting"); //Default
        oldCompany = new Company();
        nameEditText = (EditText)findViewById(R.id.edit_text_name);
        phoneEditText = (EditText)findViewById(R.id.edit_text_phone);
        urlEditText = (EditText) findViewById(R.id.edit_text_url);
        productsEditText = (EditText)findViewById(R.id.edit_text_products);
        emailEditText = (EditText)findViewById(R.id.edit_text_email);
        radioGroup = (RadioGroup) findViewById(R.id.radio_type);
        consultingRadioButton = (RadioButton) findViewById(R.id.radio_consulting);
        developmentRadioButton = (RadioButton) findViewById(R.id.radio_development);
        factoryRadioButton = (RadioButton) findViewById(R.id.radio_software);

        addUpdateButton = (Button)findViewById(R.id.button_add_update_company);
        companyData = new CompanyOperations(this);
        companyData.open();


        mode = getIntent().getStringExtra(EXTRA_ADD_UPDATE);

        if(mode.equals("Update")){

            addUpdateButton.setText("Update Company");
            compId = getIntent().getLongExtra(EXTRA_COMP_ID,0);
            Log.i("update", String.valueOf(compId));
            initializeCompany(compId);
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // find which radio button is selected
                if (checkedId == R.id.radio_consulting) {
                    newCompany.setType("Consulting");
                    if(mode.equals("Update")){
                        oldCompany.setType("Consulting");
                    }
                } else if (checkedId == R.id.radio_development) {
                    newCompany.setType("Software Development");
                    if(mode.equals("Update")){
                        oldCompany.setType("Software Development");
                    }
                } else if (checkedId == R.id.radio_software) {
                    newCompany.setType("Software Factory");
                    if(mode.equals("Update")){
                        oldCompany.setType("Software Factory");
                    }
                }

            }

        });

        addUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mode.equals("Add")) {
                    try{
                        newCompany.setName(nameEditText.getText().toString());
                        newCompany.setPhone_number(Integer.valueOf(phoneEditText.getText().toString()));
                        newCompany.setUrl(urlEditText.getText().toString());
                        newCompany.setProducts(productsEditText.getText().toString());
                        newCompany.setEmail(emailEditText.getText().toString());
                        if(factoryRadioButton.isChecked()){
                            newCompany.setType("Software Factory");
                        }
                        else if(consultingRadioButton.isChecked()){
                            newCompany.setType("Consulting");
                        }
                        else if(developmentRadioButton.isChecked()){
                            newCompany.setType("Software Development");
                        }
                        else{
                            newCompany.setType("Consulting"); //Default
                        }
                        Log.i("NEW COMPANY", newCompany.toString());
                        companyData.addCompany(newCompany);
                        Toast t = Toast.makeText(AddUpdateCompany.this, "Company "+ newCompany.getName() + "has been added successfully !", Toast.LENGTH_SHORT);
                        t.show();
                        Intent i = new Intent(AddUpdateCompany.this,MainActivity.class);
                        startActivity(i);
                    }catch (Exception e){
                        Log.i(e.toString(), "ERROR");
                    }

                }else {
                    oldCompany.setName(nameEditText.getText().toString());
                    oldCompany.setPhone_number(Integer.valueOf(phoneEditText.getText().toString()));
                    oldCompany.setUrl(urlEditText.getText().toString());
                    oldCompany.setEmail(emailEditText.getText().toString());
                    oldCompany.setProducts(productsEditText.getText().toString());
                    if(factoryRadioButton.isChecked()){
                        oldCompany.setType("Software Factory");
                    }
                    else if(consultingRadioButton.isChecked()){
                        oldCompany.setType("Consulting");
                    }
                    else if(developmentRadioButton.isChecked()){
                        oldCompany.setType("Software Development");
                    }
                    else{
                        oldCompany.setType("Consulting"); //Default
                    }
                    companyData.updateCompany(oldCompany);
                    Toast t = Toast.makeText(AddUpdateCompany.this, "Company "+ oldCompany.getName() + " has been updated successfully !", Toast.LENGTH_SHORT);
                    t.show();
                    Intent i = new Intent(AddUpdateCompany.this,MainActivity.class);
                    startActivity(i);

                }
            }
        });
    }

    private void initializeCompany(long compId) {
        oldCompany = companyData.getCompany(compId);
        if(oldCompany.getId() != 0){
            Log.i("OLD COMPANY", oldCompany.toString());
            nameEditText.setText(oldCompany.getName());
            urlEditText.setText(oldCompany.getUrl());
            phoneEditText.setText(String.valueOf(oldCompany.getPhone_number()));
            emailEditText.setText(oldCompany.getEmail());
            productsEditText.setText((oldCompany.getProducts()));
            Log.i("Consulting", oldCompany.getType() + (oldCompany.getType().equalsIgnoreCase("Consulting")));
            Log.i("SD", oldCompany.getType() + (oldCompany.getType().equalsIgnoreCase("Software Development")));
            Log.i("SF", oldCompany.getType() + (oldCompany.getType().equalsIgnoreCase("Software Factory")));
            if (oldCompany.getType().equalsIgnoreCase("Consulting")) {
                radioGroup.check(R.id.radio_consulting);
            }
            else if (oldCompany.getType().equalsIgnoreCase("Software Development")) {
                radioGroup.check(R.id.radio_development);
            }
            else if (oldCompany.getType().equalsIgnoreCase("Software Factory")) {
                radioGroup.check(R.id.radio_software);
            }
        }
        else{
            Toast t = Toast.makeText(AddUpdateCompany.this, "Company "+ String.valueOf(compId) + " does not exist", Toast.LENGTH_SHORT);
            t.show();
            Intent i = new Intent(AddUpdateCompany.this,MainActivity.class);
            startActivity(i);
        }

    }
}
