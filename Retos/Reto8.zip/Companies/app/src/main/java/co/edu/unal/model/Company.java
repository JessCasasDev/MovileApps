package co.edu.unal.model;

import java.sql.Array;

public class Company {

    private long id;
    private String name;
    private String url;
    private int phone_number;
    private String email;
    private String type; //consultoría, desarrollo a la medida y/o fábrica de software
    private String products;

    public Company(){

    }
    public Company(long id, String name, String url, int phone_number, String email, String type, String products) {

        this.id = id;
        this.name = name;
        this.url = url;
        this.phone_number = phone_number;
        this.email = email;
        this.type = type;
        this.products = products;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setPhone_number(int phone_number) {
        this.phone_number = phone_number;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setProducts(String products) {
        this.products = products;
    }

    public long getId() {

        return id;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public int getPhone_number() {
        return phone_number;
    }

    public String getEmail() {
        return email;
    }

    public String getType() {
        return type;
    }

    public String getProducts() {
        return products;
    }
    @Override
    public String toString() {
        String data = "Id: " + getId() +
                "\nName: " + getName() +
                "\nPhone: " + getPhone_number() +
                "\nEmail: " + getEmail() +
                "\nWeb Page: " + getUrl() +
                "\nCompany Type: " + getType() +
                "\nProducts: " + getProducts();

        return data;
    }
}
