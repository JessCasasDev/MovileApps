package co.edu.unal.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import co.edu.unal.model.Company;

public class CompanyOperations {
    public static final String LOGTAG = "COMP_MNGMNT_SYS";

    SQLiteOpenHelper dbhandler;
    SQLiteDatabase database;

    private static final String[] allColumns = {
            CompanyDBHandler.COLUMN_ID,
            CompanyDBHandler.COLUMN_NAME,
            CompanyDBHandler.COLUMN_PHONE_NUMBER,
            CompanyDBHandler.COLUMN_EMAIL,
            CompanyDBHandler.COLUMN_TYPE,
            CompanyDBHandler.COLUMN_URL,
            CompanyDBHandler.COLUMN_PRODUCTS
    };

    public CompanyOperations(Context context){
        dbhandler = new CompanyDBHandler(context);
    }

    public void open(){
        Log.i(LOGTAG,"Database Opened");
        database = dbhandler.getWritableDatabase();
    }

    public void close(){
        Log.i(LOGTAG, "Database Closed");
        dbhandler.close();

    }
    public Company addCompany(Company company){
        ContentValues values  = new ContentValues();
        values.put(CompanyDBHandler.COLUMN_NAME, company.getName());
        values.put(CompanyDBHandler.COLUMN_PHONE_NUMBER, company.getPhone_number());
        values.put(CompanyDBHandler.COLUMN_EMAIL, company.getEmail());
        values.put(CompanyDBHandler.COLUMN_URL, company.getUrl());
        values.put(CompanyDBHandler.COLUMN_PRODUCTS, company.getProducts());
        values.put(CompanyDBHandler.COLUMN_TYPE, company.getType());
        long insertid = database.insert(CompanyDBHandler.TABLE_COMPANY, null, values);
        company.setId(insertid);
        return company;
    }

    // Getting single Company
    public Company getCompany(long id) {
        Log.i("COMPANY OPERATIONS", String.valueOf(id));
        Cursor cursor;
        Company company = new Company();
        try{
            cursor = database.query(CompanyDBHandler.TABLE_COMPANY, allColumns, CompanyDBHandler.COLUMN_ID +
                    "=?",new String[]{String.valueOf(id)},null,null, null, null);
            if (cursor != null)
                cursor.moveToFirst();
            Log.i("CURSOR - ", cursor.toString());
            Log.i("CURSOR - 0", cursor.getString(0));
            Log.i("CURSOR - 1", cursor.getString(1));
            Log.i("CURSOR - 2", cursor.getString(2));
            Log.i("CURSOR - 3", cursor.getString(3));
            Log.i("CURSOR - 4", cursor.getString(4));
            Log.i("CURSOR - 5", cursor.getString(5));
            Log.i("CURSOR - 6", cursor.getString(6));
            company = new Company(Long.parseLong(cursor.getString(0)),cursor.getString(1),cursor.getString(5),
                    Integer.valueOf(cursor.getString(2)), cursor.getString(3),cursor.getString(4), cursor.getString(6) );
            Log.i("Company", company.toString());
        }catch (Exception e){
            Log.i("COMPANY OPERATIONS", e.toString());
        }

        return company;
    }

    public List<Company> getAllCompanies() {

        Cursor cursor = database.query(CompanyDBHandler.TABLE_COMPANY,allColumns,null,null,null, null, null);

        List<Company> companies = new ArrayList<>();
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Company company = new Company();
                company.setId(cursor.getLong(cursor.getColumnIndex(CompanyDBHandler.COLUMN_ID)));
                company.setName(cursor.getString(cursor.getColumnIndex(CompanyDBHandler.COLUMN_NAME)));
                company.setPhone_number(cursor.getInt(cursor.getColumnIndex(CompanyDBHandler.COLUMN_PHONE_NUMBER)));
                company.setEmail(cursor.getString(cursor.getColumnIndex(CompanyDBHandler.COLUMN_EMAIL)));
                company.setType(cursor.getString(cursor.getColumnIndex(CompanyDBHandler.COLUMN_TYPE)));
                company.setUrl(cursor.getString(cursor.getColumnIndex(CompanyDBHandler.COLUMN_URL)));
                company.setProducts(cursor.getString(cursor.getColumnIndex(CompanyDBHandler.COLUMN_PRODUCTS)));
                companies.add(company);
            }
        }
        return companies;
    }

    public int updateCompany(Company company) {

        ContentValues values = new ContentValues();
        values.put(CompanyDBHandler.COLUMN_NAME, company.getName());
        values.put(CompanyDBHandler.COLUMN_URL, company.getUrl());
        values.put(CompanyDBHandler.COLUMN_PHONE_NUMBER, company.getPhone_number());
        values.put(CompanyDBHandler.COLUMN_EMAIL, company.getEmail());
        values.put(CompanyDBHandler.COLUMN_PRODUCTS, company.getProducts());
        values.put(CompanyDBHandler.COLUMN_TYPE, company.getType());

        // updating row
        return database.update(CompanyDBHandler.TABLE_COMPANY, values,
                CompanyDBHandler.COLUMN_ID + "=?",new String[] { String.valueOf(company.getId())});
    }

    public void removeCompany(Company company) {

        database.delete(CompanyDBHandler.TABLE_COMPANY, CompanyDBHandler.COLUMN_ID + "=" + company.getId(), null);
    }

}
