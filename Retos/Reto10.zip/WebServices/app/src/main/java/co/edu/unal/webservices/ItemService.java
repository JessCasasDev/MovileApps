package co.edu.unal.webservices;


import android.content.ClipData;
import android.util.Log;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

class ItemService {

    public List<MyItem> findAllItems() throws JSONException {
        String result = RestOperation.getJSON(
                "https://www.datos.gov.co/api/views/hi7p-qygt/rows.json",20000);
      //  Log.e("DATA DATA", result);
        List<MyItem> foundItems = new ArrayList<>(20);
        try{
            JSONObject jsonRoot  = new JSONObject(result);

            JSONArray  jsonData = jsonRoot.getJSONArray("data");
            ArrayList<Object> m = new ArrayList<>();
            for(int i=0; i<jsonData.length();i++) {
               JSONArray ma = jsonData.getJSONArray(i);
                //String rango_edad, String genero, String tasa, String casos
                foundItems.add(
                        new MyItem(
                            ma.get(8).toString(), "Hombre", ma.get(11).toString(), ma.get(9).toString()
                        )
                );
                foundItems.add(
                        new MyItem(
                                ma.get(8).toString(), "Mujer", ma.get(14).toString(), ma.get(12).toString()
                        )
                );
            }

        }catch (Exception e){
            Log.e("Exception", e.toString());
        }

        return foundItems;
    }
}

