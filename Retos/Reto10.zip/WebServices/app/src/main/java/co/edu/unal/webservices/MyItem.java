package co.edu.unal.webservices;


public class MyItem {

    String rango_edad;
    String genero;
    String tasa;
    String casos;

    public String getRango_edad() {
        return rango_edad;
    }

    public void setRango_edad(String rango_edad) {
        this.rango_edad = rango_edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTasa() {
        return tasa;
    }

    public void setTasa(String tasa) {
        this.tasa = tasa;
    }

    public String getCasos() {
        return casos;
    }

    public void setCasos(String casos) {
        this.casos = casos;
    }

    public MyItem(String rango_edad, String genero, String tasa, String casos) {
        this.rango_edad = rango_edad;
        this.genero = genero;
        this.tasa = tasa;
        this.casos = casos;
    }

    public MyItem(){

    }


    @Override
    public String toString(){
        return "Género: " + this.getGenero() + "\nRango de Edad: " + this.getRango_edad() +
                "\nCasos: " + this.getCasos() + "\nTasa (x1000 habitantes): " + this.getTasa();
    }
}
