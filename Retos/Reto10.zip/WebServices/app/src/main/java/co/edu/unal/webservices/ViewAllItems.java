package co.edu.unal.webservices;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewAllItems extends ListActivity {

    private List<MyItem> itemsList = new ArrayList<>(20);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new RequestItemsServiceTask().execute();
        setContentView(R.layout.view_all);
    }

    /**
     * populate list in background while showing progress dialog.
     */
    private class RequestItemsServiceTask
            extends AsyncTask<Void, Void, Void> {
        private ProgressDialog dialog =
                new ProgressDialog(ViewAllItems.this);


        @Override
        protected void onPreExecute() {
            // TODO i18n
            dialog.setMessage("Please wait..");
            dialog.show();
        }

        @Override
        protected Void doInBackground(Void... unused) {
            // The ItemService would contain the method showed
            // in the previous paragraph
            ItemService itemService = new ItemService();
            try {
                itemsList = itemService.findAllItems();
            } catch (Throwable e) {
                // handle exceptions
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {

            // setListAdapter must not be called at doInBackground()
            // since it would be executed in separate Thread
            ArrayAdapter<MyItem> adapter = new ArrayAdapter<>(ViewAllItems.this,
                    android.R.layout.simple_list_item_1, itemsList);
            setListAdapter(adapter);
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
        }
    }
}